import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import{PasswordStrengthValidator} from './password.validating'
import { FormBuilder, FormGroup} from
  "@angular/forms"
import{Router} from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public myForms: FormGroup;
  showDetails: boolean;

  pswd:string;
  cpswd:string;
  constructor(private router: Router,fb: FormBuilder) { 
    this.myForms = fb.group({
      password: [null, Validators.compose([
        Validators.required, Validators.minLength(8), PasswordStrengthValidator])]
    });
  }

  ngOnInit(): void {
    
    }

  email = new FormControl('', [Validators.required, Validators.email]);

  getErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }

    return this.email.hasError('email') ? 'Not a valid email' : '';
  }
  
  hide = true;
  OnClick() {
    this.router.navigateByUrl('/first');
}

}
